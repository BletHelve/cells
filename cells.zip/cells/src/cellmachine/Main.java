package cellmachine;

import field.Rule;
import parm.Parm;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import cell.Cell;

public class Main {

    public static void main(String[] args) {
        CellMachine machine = new CellMachine();

//        Cell[] neighbour = Cell.cellArray(new int[]{2,1,4,3});
//        ArrayList<Rule>[] ruleLists = Rule.make(Parm.RULE_LANGTON_LOOP_TXT, 8, 4);
//        for (ArrayList<Rule> ruleList:ruleLists) {
//            for (Rule rule : ruleList) {
//                rule.print();
//            }
//        }


    }
}

